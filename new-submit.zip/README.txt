How to compile?
javac RingAlgo.java 

How to run?
java RingAlgo

The sample input file is input.dat
- First line is number of processes to be created
- Following lines contain the ids of the processes

The output file is output.txt
Screenshot of output is attached in the Screenshots folder.