import java.util.List;

public class IDs {
	
	private int[] idArr;
	
	public IDs(int[] ids) {
		this.idArr = ids;
	}

	public int getMyId(int index) {
		return this.idArr[index];
	}	
}
